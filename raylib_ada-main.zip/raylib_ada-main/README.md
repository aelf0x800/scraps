# raylib_ada
Raylib bindings for Ada

# NOTE
Highly incomplete and could be way better. I am a bit concerned about the number of allocations occuring
due to converting between String to a chars_ptr. Please create an issue if you have any other way of
converting String to chars_ptr with no allocation (Not sure if it is even possible).
